# API de services 
nodejs

installation
npm install

lancer le serveur
node app.js

vous devez avoir dans la console les 2 lignes suivantes:
- Server Started on port 2500
- Connected to database

NB: il faut lancer la commande "mongod" dans la terminal sinon vous aurez dans la console apres lancer le serveur:
- Unable to connect to the database undefined