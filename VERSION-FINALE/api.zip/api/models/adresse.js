const mongoose = require('mongoose');
const Schema = mongoose.Schema;
 
const adresseSchema = new Schema ({
    location : {
        type: String
    },
    utilisateur : {
        type: Schema.ObjectId,
        ref: 'User'
    },
});

adresseSchema.methods.getAdresses=function () {
    return({
        _id: this._id,
        location: this.location,
        utilisateur: userId

    })
};

var adresseModel = mongoose.model('Adresse', adresseSchema);
module.exports = {
    adresseModel : adresseModel,
    adresseSchema : adresseSchema
};