module.exports = {
    'SECRET': 'MySecret',
    'DATABASE': 'mongodb://localhost:27017/TechBook_db',
    'PORT': '3001',
    //'host':'http://localhost:3000/'
    'host':'http://192.168.1.12:3001/'
};